CREATE DATABASE  IF NOT EXISTS `backend-test` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `backend-test`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win32 (AMD64)
--
-- Host: localhost    Database: backend-test
-- ------------------------------------------------------
-- Server version	5.7.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `role_id` int(10) unsigned NOT NULL DEFAULT '3',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Mckenna','O\'Kon','percival.cremin@example.net','$2y$10$KTQPg8L2mfcLN0kMCQ.t9.hgeB.Q7KUhJEQ1AMSypKFnoMrkVNI9G',NULL,1,3,'1974-08-22 23:16:28','2017-02-06 22:15:12',NULL),(2,'Katharina','Green','chesley.schoen@example.org','$2y$10$/MHnSbbYe3A7t8TV6MPAPe3FaBeUvH7QdHYY.J1URXIU3CIxjlZZW',NULL,1,3,'2008-02-04 22:24:38','2017-02-06 22:15:12',NULL),(3,'Lila','Daniel','frami.camren@example.com','$2y$10$hMi5omACyTIigGfUm5CM8ONsQTTTOinuRI5yy0z9Y4jZVkNEZGMba',NULL,1,3,'1992-10-27 08:50:08','2017-02-06 22:15:12',NULL),(4,'Irma','McGlynn','dhickle@example.org','$2y$10$UqByRwfHsPB5qDt8waS7P.0haw/C16zawQGqtEhap2cIhFdmQMm0S',NULL,1,3,'2002-11-28 12:53:21','2017-02-06 22:15:12',NULL),(5,'Skyla','Prohaska','tgrimes@example.com','$2y$10$/zI5zLEZGX2T7qZBMhl2tOFyXnvKt5f6tnMmwNuL/SNk775C/hYkm',NULL,1,3,'2016-02-03 01:45:08','2017-02-06 22:15:12',NULL),(6,'Celestine','Schamberger','ecormier@example.net','$2y$10$6FSsrVVpzc9QKmwS7ND7i.EXqdu4pjmr2kxvGh5YNXw7kwSCvLpvK',NULL,1,3,'1975-05-07 13:40:35','2017-02-06 22:15:12',NULL),(7,'Camden','Howell','raynor.reggie@example.org','$2y$10$H/WrKHYOWwolsAauGqbo/erqWkM6ZYYFekUn/BSElHPvo3ZsvR.ru',NULL,1,3,'1973-01-19 01:45:32','2017-02-06 22:15:12',NULL),(8,'Marshall','McCullough','spinka.brenna@example.net','$2y$10$WqkCR3K9okJBFtnfiuJzxOW2zoAfu3htUwemqzVG9xDl.oKXc0bhu',NULL,1,3,'2014-12-30 06:49:32','2017-02-06 22:15:12',NULL),(9,'Eloisa','Lemke','schuppe.jimmie@example.com','$2y$10$ALboe0.lsJlK.VlBtYgM3.kdVx2Xl06mCxM4ho.5vvPzi4QyH/l2q',NULL,1,3,'1978-06-14 20:36:13','2017-02-06 22:15:12',NULL),(10,'Vilma','Nikolaus','priscilla.pacocha@example.org','$2y$10$L/kLGdgj/8stpJcbWDHY1.6H233i0bPF.l2CRz1MgTp7CPmvT1NOG',NULL,1,3,'1999-07-09 21:03:09','2017-02-06 22:15:12',NULL),(11,'Winnifred','Smith','beaulah17@example.com','$2y$10$CvZpx2/XRJwgTUCOU5iBjO70GkxAUiK.enTzaW2gry2o3Vf7tukgS',NULL,1,3,'2000-04-03 15:01:29','2017-02-06 22:15:12',NULL),(12,'Chanel','Mills','ecummings@example.net','$2y$10$ETLRzIp1CI1/g4/0gwvjQ.1vjoTIu8GV4qr/En1VllRZSqw/2K0g6',NULL,1,3,'2006-12-01 11:34:24','2017-02-06 22:15:12',NULL),(13,'Rosa','Torp','ejast@example.org','$2y$10$0hWqXGvh3CY9LIGqAUh.3.U.8n/p42dLu8u7iu6DkgJJ0qJtddpbq',NULL,1,3,'1985-09-08 10:29:01','2017-02-06 22:15:12',NULL),(14,'Estella','Gutmann','margret47@example.com','$2y$10$ZkL0YgUmK17vObSi6zeRn.qHfI83GSNSOgdehrPAvsRn4l9odKZUS',NULL,1,3,'1985-08-18 17:29:49','2017-02-06 22:15:12',NULL),(15,'Amos','Blanda','ilene.hackett@example.org','$2y$10$cCganqFIyIt5AtuR7mrnl.OmdFODi8f6ErjRXrF0.Ry4eTvW1tWQm',NULL,1,3,'1991-11-02 21:51:42','2017-02-06 22:15:12',NULL),(16,'Ora','Bauch','claude.flatley@example.com','$2y$10$RIGCxAVi6N53muMUqEBP9u6Lgq7Y6P.cHhTcztrYZH6w3YlJPbROG',NULL,1,3,'1986-02-02 15:30:25','2017-02-06 22:15:12',NULL),(17,'Joyce','Sporer','carlotta.runolfsdottir@example.org','$2y$10$fK8Cl4E25nMx0BPQjAOj6uEFWe/k7WWJzly1OAvCFz6Pncj100V3K',NULL,1,3,'1997-08-26 17:22:33','2017-02-06 22:15:12',NULL),(18,'Lambert','Keeling','jeff63@example.com','$2y$10$3.SuyN4Yper0NL6RQho8xutOrpa8qScYTp/oLA1bIY.2Cxqcre57e',NULL,1,3,'2003-03-28 18:59:23','2017-02-06 22:15:12',NULL),(19,'Jermaine','Emmerich','kristy02@example.net','$2y$10$oGZ4KJErUqC87VYpNK9K1upwXESXt8K/xt1yLj1NScNjHn6GvIur6',NULL,1,3,'2007-12-17 23:29:20','2017-02-06 22:15:12',NULL),(20,'Elijah','Herman','jbashirian@example.com','$2y$10$rNJ/vqTSVFwKcWJi7sTQjOg5TgZqfboFbvGSfw.fhzgKL/xKMgui6',NULL,1,3,'1974-04-28 12:32:43','2017-02-06 22:15:12',NULL),(21,'Alberta','Ondricka','mills.kavon@example.com','$2y$10$D7JRRGd0qelUJVgwa0ZhEeFjhGdwkc7Rb6zxWJBEbMJwzjLCRofzm',NULL,1,3,'1975-01-04 01:05:44','2017-02-06 22:15:12',NULL),(22,'Rene','Fay','talon.haag@example.org','$2y$10$nixzxalMH5D0/TyHGaDSeu282mK.Jz1FVTzE2QY0Ru2po3MCLev6G',NULL,1,3,'1981-11-14 14:57:43','2017-02-06 22:15:12',NULL),(23,'Mariane','Lueilwitz','melyssa.stoltenberg@example.org','$2y$10$HoIn8gFCZVg38gftrJSUGu4duVF63ObTle1mTfM2baEf2tvFZ9PR6',NULL,1,3,'1978-04-13 16:26:20','2017-02-06 22:15:12',NULL),(24,'Kyla','Kuvalis','effertz.isai@example.com','$2y$10$/P03cQtNJribtY0VEa50X.LcjHlFvVdvN1BlEmHAA2onc4OdCJCCq',NULL,1,3,'1981-04-24 00:52:54','2017-02-06 22:15:12',NULL),(25,'Fabiola','Mante','rohan.eileen@example.net','$2y$10$QplO9mAgJVNKAS/.XWdJMupLMugOffy54GQqCGcHX52rhl4yp5NCa',NULL,1,3,'2009-11-19 10:00:23','2017-02-06 22:15:12',NULL),(26,'Shanel','Crist','cbraun@example.net','$2y$10$auisEoXhTkhVlyxM7/DtsOwZya8ZGpmPgk0dzSbPRaYtlChrOhyTu',NULL,1,3,'1989-04-30 00:17:27','2017-02-06 22:15:12',NULL),(27,'Efrain','Tromp','uzemlak@example.com','$2y$10$C3/oR6rFSaKVr2dvKQLv3OnURPZaypCodpZ3megFSD/3fpHj.CKMq',NULL,1,3,'2000-09-28 09:49:02','2017-02-06 22:15:12',NULL),(28,'Brittany','Lesch','bartoletti.elmira@example.com','$2y$10$.IZ1A9sY5Tc7suLe2I0RB.webMWFFAU/RUMx/ZVGpurdoxdJTGg2.',NULL,1,3,'2006-08-19 00:35:03','2017-02-06 22:15:12',NULL),(29,'Saige','Adams','kautzer.betsy@example.net','$2y$10$iWBCmvbmnAtUKICTIEq30u/2kd6/XMIL0M98A4SNv5ndVTL4Bjpgy',NULL,1,3,'2005-04-08 02:26:54','2017-02-06 22:15:12',NULL),(30,'Niko','Connelly','hermiston.presley@example.com','$2y$10$Xrw2rwmbpRqg9t1A7vjxTOLzcnY3YJfULkRZ.pd53mJpayUTAlH0m',NULL,1,3,'2001-09-14 22:33:59','2017-02-06 22:15:12',NULL),(31,'Gregorio','Roob','cmorar@example.net','$2y$10$7tpkJcE95HF6KEPAbKJpreW/BRzvxbhBkayVkfRKvn6pt9xOnq2KO',NULL,1,3,'1978-02-09 06:34:36','2017-02-06 22:15:12',NULL),(32,'Evelyn','Brown','knicolas@example.com','$2y$10$OKC22rXDxJzCmwFXYrtaGeQxC0of/gqzZx9H9kKByAOzbfOvsoXTW',NULL,1,3,'2010-12-12 13:22:23','2017-02-06 22:15:12',NULL),(33,'Angus','Stehr','orlo13@example.com','$2y$10$m7FwAQbCkH1gW5sJZ1GmcOIEhuK9/37C86YVoxbmU.wuTg2MJokoW',NULL,1,3,'1993-06-03 11:54:08','2017-02-06 22:15:12',NULL),(34,'Adela','Wisoky','leonard.watsica@example.org','$2y$10$K7.PRW7..dsbuAjUNLX.2eDys5CxAt7yyJ9lT2wparMgRQjgxsh6S',NULL,1,3,'1979-12-18 08:36:33','2017-02-06 22:15:12',NULL),(35,'Stanley','Emmerich','greyson98@example.com','$2y$10$K4qGi6ehAIVkpDIHcPmNy.f84m4FT2IpseI.FKJmU9RViFzvquaTK',NULL,1,3,'2008-05-28 05:59:07','2017-02-06 22:15:12',NULL),(36,'Adelbert','Fay','dorothea.paucek@example.com','$2y$10$.sekDPrlAwXPmNvZSbNlpO/KaqPmhEZD7bohkVd3nfuVMpDUowcR2',NULL,1,3,'1978-04-18 00:20:09','2017-02-06 22:15:12',NULL),(37,'Friedrich','Schowalter','wbecker@example.com','$2y$10$7wLR4hGjATCJ7mqewRl2u.CyUp0BISxjCtqlUJaEfxUux0TpWgqrO',NULL,1,3,'2015-12-21 14:21:37','2017-02-06 22:15:12',NULL),(38,'Darwin','Dietrich','ebeatty@example.com','$2y$10$HAbm8MpaLotPrJ5b3clZhO/g4vr7W7oeJLVTaRIdFQvhVGY0KaFCe',NULL,1,3,'2011-12-13 16:02:46','2017-02-06 22:15:12',NULL),(39,'Carter','Roberts','jrau@example.net','$2y$10$4.CLQnlYU2OGOah5tNax8ODeXH3/Y0s0D.mMRGY1ROkOpmOicIGOe',NULL,1,3,'2008-11-21 00:07:42','2017-02-06 22:15:12',NULL),(40,'Vanessa','Kihn','gusikowski.meredith@example.net','$2y$10$3skz/R727U34D/S2v/9viu4yKooh6TtTl1vzdP5MTC9kgP.DIY46e',NULL,1,3,'1980-04-18 12:31:10','2017-02-06 22:15:12',NULL),(41,'Curt','Hammes','trisha72@example.org','$2y$10$onqW3PKoOwYls.KNHjI7s.XUMRTMgrHnJyG0ShC67fLiX/GWq8piK',NULL,1,3,'1997-03-19 14:27:08','2017-02-06 22:15:12',NULL),(42,'Adrianna','Turner','schuppe.wendy@example.org','$2y$10$FGM68Ble02eUY7QXi0wtN.Y8VZFz0TetVkogpOALSA1lNJlvedSmK',NULL,1,3,'1989-02-09 11:12:02','2017-02-06 22:15:12',NULL),(43,'Alyson','Gerlach','ceasar53@example.org','$2y$10$ayeI1GLZ6FaxkaVxZF8Hve3ipAoAtydkY.lmsivf4/7oj7aNhQ8Yu',NULL,1,3,'2009-06-20 06:21:34','2017-02-06 22:15:12',NULL),(44,'Tabitha','Littel','pmacejkovic@example.org','$2y$10$BrFAVyM2w6z7tu0wZrWfduRu.w5PBmWZtsN34pUQwNLp01/.ohHV2',NULL,1,3,'1988-03-06 05:47:57','2017-02-06 22:15:12',NULL),(45,'Ahmad','Doyle','vance.marvin@example.com','$2y$10$r1e6kCxDxlvxnwDQyL.GK.qNiQOCP0Bot8RJxlD2MkadSQTpvL5pq',NULL,1,3,'2005-07-11 20:34:02','2017-02-06 22:15:12',NULL),(46,'Vivien','Renner','awhite@example.net','$2y$10$lSIAN5306gp5oB6ai02FrOQwXjoq9Z/VXppV6HUAOQN23n/HWBUyq',NULL,1,3,'1976-08-14 08:40:56','2017-02-06 22:15:12',NULL),(47,'Emile','Kilback','wolff.bernard@example.net','$2y$10$KNG8Du.aP2qOTe0HCW4dFev.z2qsJodn0vetxJVGO0Po8MHWvFfZe',NULL,1,3,'2002-10-29 02:30:12','2017-02-06 22:15:12',NULL),(48,'Karley','Lesch','judah.mohr@example.org','$2y$10$6wtD2lSVt75V.wuqKnJ8lumvWjdh1fUCJIUjm6hndrE5NXADlr8zC',NULL,1,3,'2011-11-19 03:31:09','2017-02-06 22:15:12',NULL),(49,'Isobel','Mraz','prudence.deckow@example.com','$2y$10$eIPQK89FAzrQCyKlCaIfY.tQzwO.gKnIp13eTEYdNZSztBS6Cj9hm',NULL,1,3,'1973-09-14 09:35:48','2017-02-06 22:15:12',NULL),(50,'Salvatore','Hessel','jayson.williamson@example.com','$2y$10$F9PN1tfbZYzLgtD9FncUPepYOqYZ5DR8eeGlvjq3102voRFWx8STy',NULL,1,3,'1989-08-30 19:39:20','2017-02-06 22:15:12',NULL),(51,'danny','torres','danny.torresxd@gmail.com','$2y$10$JqDGAA1ZWPOJoG5quZKlMO8yvz.SK1hzexVBxJmutkbnH5oEcxeOG',NULL,1,1,'2017-02-06 22:15:12','2017-02-06 22:15:12',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-06 12:19:00
